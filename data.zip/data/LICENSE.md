# Terms and Conditions of Use #

The data in this directory is covered under Crown Copyright, Government of
Canada, and is distributed under the
[Statistics Canada Open Licence Agreement](http://www.statcan.gc.ca/eng/reference/licence).
