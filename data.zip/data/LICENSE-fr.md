# Conditions régissant l'utilisation #

Les données dans ce répertoire sont protégées par le droit d'auteur de la
Couronne du gouvernement du Canada et distribués sous
l'[Entente de licence ouverte de Statistique Canada](http://www.statcan.gc.ca/fra/reference/licence).
